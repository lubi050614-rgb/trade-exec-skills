---
name: execution-match
description: 纯计算基于开盘价、保护价、规则和剩余共享容量的成交候选；不占用容量、不持久化成交、不修改账户。 仅用于本地股票模拟。
when_to_use: 需要在本地股票模拟会话中计算模拟成交候选时使用。
version: 0.1.0
entry: scripts/run.py
allowed_tools:
  - skill_run_script
---

# 计算模拟成交候选

纯计算基于开盘价、保护价、规则和剩余共享容量的成交候选；不占用容量、不持久化成交、不修改账户。

层级：Atomic；业务编号：STOCK-A11。调用时使用完整名称 `execution-match`，编号仅作业务映射。仅操作本地模拟账户及 `simulation_fixture` 规则，不接入真实账户或推断生产规则。

## 输入参数

参数位于 JSON 请求信封及其 `data` 对象中，下表使用完整字段路径；数组子项以 `[]` 表示。嵌套字段的必填要求在所属对象出现时适用。以[输入契约](assets/input.schema.json)为准，填写前核对[业务契约](references/contract.md)和[请求示例](assets/example.json)。

| 字段 | JSON 类型 | 必填 | 取值与含义 |
| --- | --- | --- | --- |
| `schema_version` | string | 必填 | 请求和响应协议版本，固定为 1.0；固定值 `"1.0"` |
| `request_id` | string | 必填 | 本次请求标识，响应原样返回以便追踪 |
| `account_id` | string | 必填 | 模拟账户标识，必须与初始化会话一致 |
| `simulation_id` | string | 必填 | 本地模拟会话标识，必须与初始化会话一致 |
| `data` | object | 必填 | 业务请求或成功结果对象；仅接受下列契约字段 |
| `data.order_id` | string | 必填 | 已登记订单标识，从提交或登记结果读取 |
| `data.bar` | object | 必填 | 已完成的模拟行情，标的、频率与当前会话一致；仅接受下列契约字段 |
| `data.bar.event_id` | string | 必填 | 已持久化行情事件标识；行情对象内为本事件唯一标识 |
| `data.bar.instrument_id` | string | 必填 | 会话规则中配置的模拟股票标识 |
| `data.bar.frequency` | string | 必填 | 会话行情频率：1m 或 1d；取值 `1m`、`1d` |
| `data.bar.trade_date` | string | 必填 | 会话日历中的交易日，夜盘不按自然日期推断 |
| `data.bar.start_at` | string | 必填 | 行情开始时点，使用带 +08:00 时区的时间 |
| `data.bar.end_at` | string | 必填 | 行情结束时点，使用带 +08:00 时区的时间 |
| `data.bar.open` | string | 必填 | 行情开盘价；十进制字符串 |
| `data.bar.high` | string | 必填 | 行情最高价；十进制字符串 |
| `data.bar.low` | string | 必填 | 行情最低价；十进制字符串 |
| `data.bar.close` | string | 必填 | 行情收盘价；十进制字符串 |
| `data.bar.volume` | integer | 必填 | 行情成交量；股票单位为股，期货单位为手；最小值 0 |
| `data.bar.amount` | string | 必填 | 行情成交金额；十进制字符串 |
| `data.bar.tradable` | boolean | 必填 | 本行情是否允许模拟交易 |
| `data.bar.price_limit_clear` | boolean | 必填 | 行情是否满足模拟涨跌停可成交条件 |
| `data.bar.price_basis` | string | 必填 | 价格口径，固定 UNADJUSTED，使用未复权价格；固定值 `"UNADJUSTED"` |
| `data.bar.source` | string | 必填 | 模拟行情来源 |
| `data.bar.synthetic` | boolean | 必填 | 是否为合成模拟行情 |
| `data.participation_rate` | string | 必填 | 本事件可参与成交量的比例，按会话共享容量约束；十进制字符串 |
| `data.slippage` | string | 必填 | 撮合使用的显式价格滑点；十进制字符串 |
| `idempotency_key` | string | 可选（只读接口） | 持久化操作的幂等键；相同键及载荷返回原结果，改动载荷须使用新键 |

金额和价格使用十进制字符串，时间使用带 `+08:00` 时区的显式时间。示例中的账户、标的、订单号和版本只适用于对应示例会话，实际调用须从当前会话读取。

## 调用

在技能目录中调用，关联步骤始终使用同一个数据库路径：

```text
skill_run_script { skill: "execution-match", script: "scripts/run.py", args: ["--db", "simulation.sqlite", "--input", "assets/example.json"] }
```

没有 `skill_run_script` 时，通过 Python 3.11 或以上版本直接执行相同入口：

```bash
python scripts/run.py --db simulation.sqlite --input assets/example.json
```

`--input` 指向完整请求 JSON 文件；省略时从标准输入读取 JSON。首次建立新会话时附加 `--init <session.json>`；已有会话后续调用省略 `--init`。可用初始化文件来自项目的 `examples/SSE/session.json`、`examples/SZSE/session.json` 或 `examples/BSE/session.json`。先核对输入引用的账户及资源是否存在，仅初始化账户不会自动生成订单或成交。

运行依赖打包在本技能的 `scripts/` 中，运行条件见 [runtime.json](assets/runtime.json)。stdout 返回一个 JSON 信封；退出码 0 表示 `ok=true`，退出码 1 表示错误信封。

涉及订单的示例必须先执行合法的提交或登记步骤；涉及成交应用和记账时，先有持久化行情与成交。单独的请求示例不负责创建这些前置状态。

本接口只读或只计算，不隐式修改账户、订单、成交或冻结资源。

## 输出参数

成功与失败的完整结构见[输出契约](assets/output.schema.json)，并可对照[成功响应](assets/success.json)和[失败响应](assets/failure.json)。业务字段随成功路径、订单生命周期或中断阶段出现；下表汇总各分支，不表示所有字段总会同时返回。可扩展账户、规则及持仓对象的详细结构以契约和实际快照为准。

| 字段 | JSON 类型 | 出现条件与含义 |
| --- | --- | --- |
| `ok` | boolean | 成功为 true，失败为 false |
| `schema_version` | string | 请求和响应协议版本，固定为 1.0；固定值 `"1.0"` |
| `request_id` | string | 本次请求标识，响应原样返回以便追踪 |
| `data` | object | 业务请求或成功结果对象 |
| `data.quantity` | integer | 整数股数；0 表示未成交，此时返回 reason |
| `data.price` | string | 价格或模拟成交价 |
| `data.expected_version` | integer | 当前订单版本，用于比较并更新，须先查询最新版本 |
| `data.event_id` | string | 已持久化行情事件标识；行情对象内为本事件唯一标识 |
| `data.model_version` | string | 撮合模型版本 |
| `data.reason` | string | 本次未成交或未生成动作的原因 |
| `warnings` | array of string | 成功响应中的提示列表，可能为空 |
| `error` | object | 失败时返回的错误对象 |
| `error.code` | string | 错误类别 |
| `error.message` | string | 具体错误原因 |
| `error.retryable` | boolean | 错误或中断是否支持按恢复条件重试 |
| `error.details` | object | 错误附加信息，按错误类别解释 |

先检查 `ok`；失败时读取 `error.code/message/details`，结合 `retryable` 和业务契约处理。若 `data.commit_status` 为 `ACCOUNTING_PENDING` 或 `RECOVERY_REQUIRED`，即使 `ok=true` 也未完成，须先恢复后再推进依赖交易。`COMMITTED` 仅表示当前接口的操作完成。

## 执行约束

账户及证券规则须已初始化；涉及更新时读取当前订单和账户版本。登记订单为 `PENDING_RESERVATION`，预留成功后才激活。直接撤销剩余量后须调用 `order-release-reserve`；登记成交前须有持久化行情，应用及记账前须有持久化成交。

待记账成交会阻止依赖交易。中断的模拟使用相同 bar/model、新的幂等键并去掉 fail_after 恢复；原键仍返回原中断响应。成交冲突导致 RECONCILE 时停止新提交，由可信运行时依据独立证据及版本校验完成对账，不能通过工具自行清除。详细前置条件、执行顺序和错误码见[业务契约](references/contract.md)。

## 相关上层工具

本技能执行单个领域步骤，不调用 Upper 工作流。完整流程可按需求使用：

- [execution-simulate](../execution-simulate/SKILL.md)：模拟成交并记账。
