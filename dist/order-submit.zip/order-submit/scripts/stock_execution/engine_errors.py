class ContractError(ValueError):
    pass
