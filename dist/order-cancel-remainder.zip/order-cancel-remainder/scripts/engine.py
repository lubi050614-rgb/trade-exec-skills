from stock_execution.cli import run

def execute():
    return run('order-cancel-remainder')
